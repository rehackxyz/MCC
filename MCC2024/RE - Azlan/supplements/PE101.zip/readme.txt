This is a simple Windows PE binary, generated from scratch in assembly, to walk through - see http://pe101.corkami.com

Many of the PE superfluous structures have been removed for conciseness, but it's still similar to a standard compiled PE.

http://www.corkami.com - Ange Albertini (@ange4771)